title: mysql安装
date: '2019-08-13 21:10:15'
updated: '2019-08-13 21:10:15'
tags: [mysql]
permalink: /articles/2019/08/13/1565701815326.html
---
## 添加mysql存储库
##### 安装添加发行包到yum仓库
```shell
sudo yum localinstall https://dev.mysql.com/get/mysql80-community-release-el7-3.noarch.rpm
```
##### 检查mysql yum仓库是否添加成功
```shell
yum repolist enabled | grep "mysql.*-community.*"
```
## 选择安装版本
##### 列出yum仓库中所有的mysql
```shell
yum repolist all | grep mysql
```
##### 禁用启用版本
```shell
#假设默认启用的是5.7的版本，需要安装8.0版本。则以下为禁用5.7启用8.0版本
sudo yum-config-manager --disable mysql57-community 
sudo yum-config-manager --enable mysql80-community
```
也可通过编辑`/etc/yum.repos.d/mysql-community.repo` 文件来选择版本， 
将需要的版本的enabled=1，其他版本enabled=0。如下将默认的5.7禁用，启用8.0
```
[mysql57-community]
name=MySQL 5.7 Community Server
baseurl=http://repo.mysql.com/yum/mysql-5.7-community/el/7/$basearch/
enabled=0
gpgcheck=1
gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-mysql

[mysql80-community]
name=MySQL 8.0 Community Server
baseurl=http://repo.mysql.com/yum/mysql-8.0-community/el/7/$basearch/
enabled=1
gpgcheck=1
gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-mysql
```
##### 验证启用的版本是否设置正确
```shell
yum repolist enabled | grep mysql
```
## 安装MySQL
```shell
sudo yum install mysql-community-server
```
#### 设置开机启动MySQL
```shell
sudo systemctl enable mysqld
```
#### 启动MySQL
```shell
sudo systemctl start mysqld
```
#### 查看MySQL运行状态
```shell
sudo systemctl status mysqld
```
## 登录MySQL
#### 获取安装时创建的root账户密码
```shell
sudo grep 'temporary password' /var/log/mysqld.log
```
#### 使用获取到的root密码登录
```shell
mysql -uroot -p
```
登录后会提示修改密码，修改即可
#### 设置允许远程及使用navicat登录
```sql
use mysql;
update user set host='%' where user ='root';
update user set plugin='mysql_native_password' where user ='root';
```
#### 刷新权限使修改生效
```sql
flush privileges;
```







