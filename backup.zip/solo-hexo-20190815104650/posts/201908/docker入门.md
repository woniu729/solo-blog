title: docker入门
date: '2019-08-13 21:55:11'
updated: '2019-08-13 21:55:11'
tags: [docker]
permalink: /articles/2019/08/13/1565704511290.html
---
## 安装docker
```shell
#安装
yum install docker-ce
#设置开启启动
sudo systemctl enable docker 
#启动
sudo systemctl start docker
#查看状态
sudo systemctl status docker
#查看docker版本信息
sudo docker version
```
#### 配置镜像加速
在/etc/docker/daemon.json中写入如下内容(如果文件不存在则新建该文件)，如下配置163的镜像
```
{
    "registry-mirrors":[
        "http://hub-mirror.c.163.com"
    ]
}
```
#### 重新加载配置文件并重启服务
```
sudo systemctl daemon-reload
sudo systemctl restart docker
```
#### 查看docker信息确认镜像修改成功
```
docker info
```
![屏幕快照20190813下午9.52.27.png](https://img.hacpai.com/file/2019/08/屏幕快照20190813下午9.52.27-700a0b13.png)


