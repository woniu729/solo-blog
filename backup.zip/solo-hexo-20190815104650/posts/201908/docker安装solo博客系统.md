title: docker安装solo博客系统
date: '2019-08-13 22:51:32'
updated: '2019-08-13 22:51:32'
tags: [docker]
permalink: /articles/2019/08/13/1565707892361.html
---
### 获取solo最新镜像
```
docker pull b3log/solo
```
### 启动容器
```
run --detach --name solo --network=host --env RUNTIME_DB="MYSQL" --env JDBC_USERNAME="root" --env JDBC_PASSWORD='passwd' --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" --volume /usr/local/tmp/solo/skins/:/opt/solo/skins/ b3log/solo --listen_port=8080 --server_scheme=http --server_host=blog.woniu.com --server_port=
```
#### 参数说明：
* `--listen_port`：进程监听端口
* `--server_scheme`：最终访问协议，如果反代服务启用了 HTTPS 这里也需要改为 `https`
* `--server_host`：最终访问域名或公网 IP，不要带端口
* `--server_port`：最终访问端口，使用浏览器默认的 80 或者 443 的话值留空即可
#### 配置皮肤
先在主机上创建/usr/local/tmp/solo/skins/目录存放皮肤，并从[这里](https://github.com/b3log/solo-skins)下载皮肤包解压放在该目录(否则运行失败，查看运行日志为找不到默认皮肤的错误)。添加以下参数挂载皮肤
```
--volume /usr/local/tmp/solo/skins/:/opt/solo/skins/
```
#### 查看项目运行日志
```
sudo docker logs solo
```
#### 访问博客
如果监听端口不是80端口，则需要采用nginx配置端口代理转发，添加如下nginx配置文件
```
server {
    server_name blog.woniu.com;  #修改为项目访问域名
    listen 80;

    location / {
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_http_version 1.1;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header Host $host;
        proxy_pass http://127.0.0.1:8080;
    }
}

```



